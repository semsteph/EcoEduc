import{_ as e,v as t,t as c}from"./CJ78dRAb.js";const o={};function r(n,s,a,_,p,d){return c(),t("div",null,"cc")}const i=e(o,[["render",r]]);export{i as default};
