import{_ as e,v as t,t as c}from"./CJ78dRAb.js";const o={};function n(r,s,_,a,p,l){return c(),t("div",null,"cc")}const f=e(o,[["render",n]]);export{f as default};
