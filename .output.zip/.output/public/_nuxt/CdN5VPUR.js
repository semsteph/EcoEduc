import{_ as e,v as t,t as c}from"./CJ78dRAb.js";const o={};function r(s,n,a,_,p,i){return c(),t("div",null,"cc")}const d=e(o,[["render",r]]);export{d as default};
