import{_ as e,v as t,t as c}from"./CJ78dRAb.js";const o={};function n(r,s,_,a,p,d){return c(),t("div",null,"cc")}const i=e(o,[["render",n]]);export{i as default};
