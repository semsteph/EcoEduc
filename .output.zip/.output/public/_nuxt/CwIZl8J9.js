import{_ as e,v as c,t}from"./CJ78dRAb.js";const n={};function o(r,s,_,a,p,d){return t(),c("div",null,"cc")}const i=e(n,[["render",o]]);export{i as default};
