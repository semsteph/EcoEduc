import{_ as t,v as e,t as c}from"./CJ78dRAb.js";const o={};function n(r,s,a,_,p,i){return c(),e("div",null,"cc")}const l=t(o,[["render",n]]);export{l as default};
