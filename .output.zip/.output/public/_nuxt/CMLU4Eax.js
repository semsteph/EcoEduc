import"./D18l7lqN.js";import{Y as r}from"./apIVRbER.js";const p=r("v-spacer","div","VSpacer");export{p as V};
