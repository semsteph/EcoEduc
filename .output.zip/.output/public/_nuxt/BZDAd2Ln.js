import"./CJ78dRAb.js";const r=""+new URL("logooff.D8oOLL2S.png",import.meta.url).href;export{r as _};
